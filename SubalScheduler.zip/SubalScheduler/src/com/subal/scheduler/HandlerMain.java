package com.subal.scheduler;

import java.io.IOException;
import java.util.Date;
import java.util.TimerTask;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.ExecuteException;

public class HandlerMain {
	static Date now;
	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws InterruptedException, ExecuteException, IOException {
		
		while(true){
			now = new Date(); // initialize date
			System.out.println("Time is :" + now); // Display current time
			if(now.getHours()==6){
				String line = "sh //home//pi//ScheduledJobs//scripts//Email_Manual_Trigger.sh";
				CommandLine cmdLine = CommandLine.parse(line);
				DefaultExecutor executor = new DefaultExecutor();
				int exitValue = executor.execute(cmdLine);
				System.out.println("Job Executed at "+ now+" with exit code : "+exitValue);			
			}
			Thread.sleep(1000*60*60);
		}


	}

}
