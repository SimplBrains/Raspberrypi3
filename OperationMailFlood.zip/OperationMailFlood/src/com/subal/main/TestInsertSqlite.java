package com.subal.main;

import com.subal.dao.SqliteInsert;

public class TestInsertSqlite {
	public static void main(String[] args) {
		SqliteInsert sqliteInsert = new SqliteInsert();
		sqliteInsert.insert("authut247@gmail.com", "admin");
	}

}
