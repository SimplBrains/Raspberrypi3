package com.subal.main;

import com.subal.dao.SqliteCreate;
import com.subal.dao.SqliteSelect;
import com.subal.email.HtmlEmailSender;

public class HandlerMain {
	public static void main(String[] args) {
		SqliteCreate sqliteCreate = new SqliteCreate();
		sqliteCreate.createNewTable();
		SqliteSelect sqliteSelect = new SqliteSelect();
		String emailString = sqliteSelect.selectAll();
		HtmlEmailSender htmlEmailSender = new HtmlEmailSender();
		htmlEmailSender.emailSender(emailString);
	}
	
	

}
